import heapq
from collections import deque

graph = {"A": ["B", "C"], "B": ["D", "E"], "C": ["F"], "D": [], "E": ["G"], "F": [], "G": []}

wgraph = {"A": [("B", 1), ("C", 5)], "B": [("D", 2), ("E", 1)],
          "C": [("F", 3), ("G", 7)], "D": [], "E": [("G", 1)], "F": [], "G": []}
topo = {k: [n for n, _ in v] for k, v in wgraph.items()}


def bfs(g, start, goal):
    q = deque([(start, [start])])
    seen = {start}
    steps = []
    while q:
        node, path = q.popleft()
        if node != goal:
            for n in g[node]:
                if n not in seen:
                    seen.add(n)
                    q.append((n, path + [n]))
        steps.append((node, [n for n, _ in q]))
        if node == goal:
            return path, steps
    return None, steps


def dfs(g, start, goal):
    stack = [(start, [start])]
    seen = set()
    steps = []
    while stack:
        node, path = stack.pop()
        if node in seen:
            continue
        if node == goal:
            steps.append((node, [n for n, _ in reversed(stack)]))
            return path, steps
        seen.add(node)
        for n in reversed(g[node]):
            stack.append((n, path + [n]))
        steps.append((node, [n for n, _ in reversed(stack)]))
    return None, steps


def dls(g, node, goal, limit, path):
    if node == goal:
        return "FOUND", path
    kids = [n for n in g[node] if n not in path]
    if limit == 0:
        return ("CUTOFF" if kids else "FAILURE"), None
    cut = False
    for n in kids:
        status, p = dls(g, n, goal, limit - 1, path + [n])
        if status == "FOUND":
            return status, p
        if status == "CUTOFF":
            cut = True
    return ("CUTOFF" if cut else "FAILURE"), None


def iddfs(g, start, goal, max_depth):
    tried = []
    status, path = "FAILURE", None
    for limit in range(max_depth + 1):
        tried.append(limit)
        status, path = dls(g, start, goal, limit, [start])
        if status == "FOUND":
            break
    return status, path, tried


def ucs(wg, start, goal):
    pq = [(0, 0, start, [start])]
    done = set()
    order = []
    cnt = 1
    while pq:
        cost, _, node, path = heapq.heappop(pq)
        if node in done:
            continue
        order.append((node, cost))
        if node == goal:
            return path, cost, order
        done.add(node)
        for n, w in wg[node]:
            if n not in done:
                heapq.heappush(pq, (cost + w, cnt, n, path + [n]))
                cnt += 1
    return None, None, order


def path_cost(wg, path):
    w = {(a, b): c for a, es in wg.items() for b, c in es}
    return sum(w[(path[i], path[i + 1])] for i in range(len(path) - 1))


def show_steps(title, path, steps):
    print(f"--- {title} ---")
    for i, (node, fr) in enumerate(steps, 1):
        print(f"{i}. process {node} | frontier after: {fr}")
    print("Path:", path, "| Visit order:", [s[0] for s in steps])


print("=== Task 1: BFS and DFS (A -> G) ===")
p, s = bfs(graph, "A", "G")
show_steps("BFS", p, s)
p, s = dfs(graph, "A", "G")
show_steps("DFS", p, s)

print("\n=== Task 2: DLS and IDDFS ===")
for L in (1, 2, 3, 4):
    st, p = dls(graph, "A", "G", L, ["A"])
    print(f"DLS limit {L}: {st}, path={p}")
for L in (1, 2, 3, 4):
    st, p, t = iddfs(graph, "A", "G", L)
    print(f"IDDFS max {L}: {st}, path={p}, limits tried={t}")

print("\n=== Task 3: Weighted graph (added corridor C->G = 7) ===")
print("Edges:", {k: v for k, v in wgraph.items() if v})
bp, bs = bfs(topo, "A", "G")
print("BFS path:", bp, "| hops:", len(bp) - 1, "| cost:", path_cost(wgraph, bp),
      "| order:", [x[0] for x in bs])
up, uc, uo = ucs(wgraph, "A", "G")
print("UCS path:", up, "| hops:", len(up) - 1, "| cost:", uc,
      "| verified sum:", path_cost(wgraph, up))
print("UCS processing order (node, cost):", uo)

print("\n=== Edge cases ===")
print("Start == goal  BFS:", bfs(graph, "A", "A")[0], "| UCS:", ucs(wgraph, "A", "A")[:2])
print("Unreachable (C -> D)  BFS:", bfs(graph, "C", "D")[0], "| DFS:", dfs(graph, "C", "D")[0],
      "| UCS:", ucs(wgraph, "C", "D")[:2])
cyc = {"A": ["B"], "B": ["A", "C"], "C": []}
print("Cycle graph A->C  BFS:", bfs(cyc, "A", "C")[0], "| DFS:", dfs(cyc, "A", "C")[0],
      "| IDDFS:", iddfs(cyc, "A", "C", 4)[:2])
