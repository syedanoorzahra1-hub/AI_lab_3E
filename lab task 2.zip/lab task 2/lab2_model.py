class ReflexAgent:
    def act(self, temp, occupied):
        if not occupied:
            return "ECO"
        if temp > 26:
            return "COOL"
        if temp < 20:
            return "WARM"
        return "IDLE"


class StatefulAgent(ReflexAgent):
    def __init__(self):
        self.prev = None

    def act(self, temp, occupied):
        prev = self.prev
        target = super().act(temp, occupied)
        send = target != prev
        self.prev = target
        return prev, target, send


def run_reflex():
    print("=== Reflex agent ===")
    percepts = [(29, True), (29, True), (20, True),
                (26, True), (19, True), (29, False)]
    agent = ReflexAgent()
    for i, p in enumerate(percepts, 1):
        print(i, p, "target mode", agent.act(*p))


def run_stateful(title, percepts):
    print(f"\n=== {title} ===")
    print(f"{'Step':<5}{'Prev':<7}{'Percept':<14}{'Target':<7}Command")
    agent = StatefulAgent()
    for i, p in enumerate(percepts, 1):
        prev, target, send = agent.act(*p)
        print(f"{i:<5}{str(prev):<7}{str(p):<14}{target:<7}"
              f"{'SEND' if send else 'no command'}")


if __name__ == "__main__":
    run_reflex()
    run_stateful("Stateful agent: main trace",
                 [(29, True), (29, True), (20, True), (26, True),
                  (19, True), (19, True), (29, False), (29, False),
                  (24, True)])
    run_stateful("Edge case: noisy readings around 26 C",
                 [(26.5, True), (25.8, True), (26.5, True), (25.8, True)])
