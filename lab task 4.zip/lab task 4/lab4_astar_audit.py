import heapq

graph = {"S": [("A", 1), ("B", 4)], "A": [("C", 2)], "B": [("G", 5)], "C": [("G", 3)], "G": []}
h = {"S": 5, "A": 4, "B": 4, "C": 2, "G": 0}


def astar(graph, h, start, goal):
    pq = [(h[start], 0, start, [start])]
    best = {start: 0}
    expanded, log, stale = [], [], 0
    while pq:
        f, g, node, path = heapq.heappop(pq)
        if g != best[node]:
            stale += 1
            continue
        if node == goal:
            log.append((node, g, h[node], f, live(pq, best, h)))
            return g, path, expanded, log, stale
        expanded.append(node)
        for nxt, w in graph.get(node, []):
            ng = g + w
            if ng < best.get(nxt, float("inf")):
                best[nxt] = ng
                heapq.heappush(pq, (ng + h[nxt], ng, nxt, path + [nxt]))
        log.append((node, g, h[node], f, live(pq, best, h)))
    return None, None, expanded, log, stale


def live(pq, best, h):
    items = sorted((e[2], e[1], h[e[2]], e[0]) for e in pq if e[1] == best[e[2]])
    return ", ".join(f"{n}(g={g},h={hh},f={f})" for n, g, hh, f in items)


def path_cost(graph, path):
    w = {(a, b): c for a, es in graph.items() for b, c in es}
    return sum(w[(path[i], path[i + 1])] for i in range(len(path) - 1))


def true_costs(graph, goal):
    t = {n: float("inf") for n in graph}
    t[goal] = 0
    for _ in graph:
        for a, es in graph.items():
            for b, c in es:
                t[a] = min(t[a], c + t[b])
    return t


def report(name, hh):
    g, path, exp, log, stale = astar(graph, hh, "S", "G")
    print(f"--- {name} ---")
    for i, (n, gg, h_, f, fr) in enumerate(log, 1):
        print(f"{i}. process {n}: g={gg}, h={h_}, f={f} | frontier after: {fr or 'empty'}")
    print("Path:", path, "| cost:", g, "| verified sum:", path_cost(graph, path))
    print("Expanded:", exp, "| count:", len(exp), "| stale entries skipped:", stale)
    return g, path, exp


print("=== Heuristic audit ===")
tc = true_costs(graph, "G")
print("True remaining costs:", tc)
print("Admissible:", all(h[n] <= tc[n] for n in h))
for u, es in graph.items():
    for v, c in es:
        print(f"{u}->{v}: h({u})={h[u]} <= {c}+h({v})={c + h[v]} ->", h[u] <= c + h[v])

print("\n=== Task 1 & 2: A* vs UCS ===")
a = report("A* (supplied h)", h)
u = report("UCS (h = 0)", {n: 0 for n in h})

print("\n=== Comparison ===")
print(f"{'Method':<8}{'Path':<14}{'Cost':<6}Expanded")
print(f"{'A*':<8}{'-'.join(a[1]):<14}{a[0]:<6}{len(a[2])}")
print(f"{'UCS':<8}{'-'.join(u[1]):<14}{u[0]:<6}{len(u[2])}")

print("\n=== Task 3: overestimate h(C) = 2 -> 10 ===")
h2 = dict(h)
h2["C"] = 10
print("True remaining cost of C:", tc["C"], "| h(C) =", h2["C"], "(overestimate)")
o = report("A* with h(C)=10", h2)
print("Changed:", "path" if o[1] != a[1] else "", "cost" if o[0] != a[0] else "", "expanded count" if len(o[2]) != len(a[2]) else "")

print("\n=== Edge cases ===")
print("Start == goal:", astar(graph, h, "G", "G")[:2])
print("Unreachable (G -> S):", astar(graph, h, "G", "S")[:2])
